

css = """<style>
		h1{
			position: relative;
		}
		
		img{
				padding: 5px;
				position: relative;
		}
		
		#search_img_box{
			text-align: right;
			position: absolute;
			top: 10px;
			right: 0px;
		}
		#search_artist_box{
			text-align: right;
			position: absolute;
			top: 60px;
			right: 0px;
		}
		
		#gallery_spacing{
			
		}
	</style>"""